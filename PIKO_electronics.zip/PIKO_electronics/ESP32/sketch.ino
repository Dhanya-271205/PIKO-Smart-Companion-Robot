#include <Wire.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>

const char* ssid = "Wokwi-GUEST";
const char* password = "";
const char* serverURL = "http://host.wokwi.internal:3001/api/sensors";

Adafruit_MPU6050 mpu;

#define PIR_PIN 27
#define SDA_PIN 21
#define SCL_PIN 22

void setup() {
  Serial.begin(115200);
  pinMode(PIR_PIN, INPUT);
  Wire.begin(SDA_PIN, SCL_PIN);

  if (!mpu.begin()) {
    Serial.println("MPU6050 not detected!");
    while (true) {
      delay(10);
    }
  }

  mpu.setAccelerometerRange(MPU6050_RANGE_8_G);
  mpu.setGyroRange(MPU6050_RANGE_500_DEG);
  mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);

  Serial.println("PIKO SAFETY SYSTEM");
  Serial.println("MPU6050 connected!");
  Serial.println("PIR monitoring started!");

  WiFi.begin(ssid, password);
  Serial.print("Connecting to Wi-Fi");

  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 60) {
    delay(500);
    Serial.print(".");
    attempts++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nWi-Fi connected!");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("\nWi-Fi connection failed. Sensor monitoring will continue.");
  }
}

void loop() {
  int motion = digitalRead(PIR_PIN);

  sensors_event_t acceleration;
  sensors_event_t gyroscope;
  sensors_event_t temperature;
  mpu.getEvent(&acceleration, &gyroscope, &temperature);

  float ax = acceleration.acceleration.x;
  float ay = acceleration.acceleration.y;
  float az = acceleration.acceleration.z;
  float totalAcceleration = sqrt(ax * ax + ay * ay + az * az);

  float gx = gyroscope.gyro.x;
  float gy = gyroscope.gyro.y;
  float gz = gyroscope.gyro.z;
  float totalRotation = sqrt(gx * gx + gy * gy + gz * gz);

  Serial.println("\n----- PIKO SENSOR STATUS -----");
  Serial.println(motion ? "ROOM ACTIVITY: Motion detected" :
                          "ROOM ACTIVITY: No motion detected");
  Serial.print("TOTAL ACCELERATION: ");
  Serial.println(totalAcceleration, 2);
  Serial.print("TOTAL ROTATION: ");
  Serial.println(totalRotation, 2);
  Serial.print("TEMPERATURE: ");
  Serial.println(temperature.temperature, 2);

  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;
    http.begin(serverURL);
    http.addHeader("Content-Type", "application/json");

    String payload = "{";
    payload += "\"motion\":";
    payload += motion ? "true" : "false";
    payload += ",\"acceleration\":";
    payload += String(totalAcceleration, 2);
    payload += ",\"rotation\":";
    payload += String(totalRotation, 2);
    payload += ",\"temperature\":";
    payload += String(temperature.temperature, 2);
    payload += ",\"wifi\":true";
    payload += "}";

    int responseCode = http.POST(payload);
    Serial.print("SERVER RESPONSE: ");
    Serial.println(responseCode);

    if (responseCode > 0) {
      Serial.println(http.getString());
    } else {
      Serial.println("Failed to send sensor data!");
    }
    http.end();
  } else {
    Serial.println("WI-FI: Disconnected");
  }

  delay(1000);
}
